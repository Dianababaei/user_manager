// Main method to run the UserManager application
public class main {
    public main(String[] args) {
        UserManager userManager = new UserManager();
        userManager.run();
    }
}